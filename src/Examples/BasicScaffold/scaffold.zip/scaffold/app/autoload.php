<?php
spl_autoload_register(function ($className)
{
    if (false == class_exists($className, false))
    {
        $appDefaultDirectories = array(
            __DIR__, 
            __DIR__.'/models', 
            __DIR__.'/controllers');

    	foreach ($appDefaultDirectories as $dir) 
    	{
    		$fileName = $dir . DIRECTORY_SEPARATOR . str_replace('\\', DIRECTORY_SEPARATOR, $className) . '.php';
	        if (file_exists($fileName) && is_readable($fileName))
	        {
	            include_once($fileName);
                break;
	        }
    	}
    }
});