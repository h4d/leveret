<?php

use H4D\Leveret\Application\Controller;

class DefaultController extends Controller
{
    public function index()
    {
        $this->getResponse()->setBody('Hello!');
    }
}