<?php
// INI: PHP Directives /////////////////////////////////////////////////////////////////////////////
error_reporting(E_ALL | E_STRICT);
date_default_timezone_set('Europe/Madrid');
// END: PHP Directives /////////////////////////////////////////////////////////////////////////////

// INI: Constants definition ///////////////////////////////////////////////////////////////////////
define('APP_DIR', __DIR__);
define('APP_CONFIG_DIR', APP_DIR . '/config');
define('APP_MODELS_DIR', APP_DIR . '/models');
define('APP_CONTROLLERS_DIR', APP_DIR . '/controllers');
define('APP_LOGS_DIR', APP_DIR . '/logs');
define('EXTERNAL_LIBS_DIR', APP_DIR . '/../../vendor');
// END: Constants definitio ////////////////////////////////////////////////////////////////////////

// INI: Requirements ///////////////////////////////////////////////////////////////////////////////
// Application autoload
require_once(APP_DIR . '/autoload.php');
// External libraries autoload
require_once(EXTERNAL_LIBS_DIR . '/autoload.php');
require_once(EXTERNAL_LIBS_DIR . '/H4D/autoload.php');
// END: Requirements ///////////////////////////////////////////////////////////////////////////////

// INI: Dependencies ///////////////////////////////////////////////////////////////////////////////
// Init logger
H4D\Logger::i()
          ->addWriter(new H4D\Logger\Writer\File(APP_LOGS_DIR . '/' . date('Y-m-d') . '.log',
                                                 array(
                                                     H4D\Logger\Levels::LEVEL_DEBUG,
                                                     H4D\Logger\Levels::LEVEL_INFO,
                                                     H4D\Logger\Levels::LEVEL_NOTICE,
                                                     H4D\Logger\Levels::LEVEL_WARNING,
                                                     H4D\Logger\Levels::LEVEL_ALERT,
                                                     H4D\Logger\Levels::LEVEL_CRITICAL,
                                                     H4D\Logger\Levels::LEVEL_EMERGENCY,
                                                     H4D\Logger\Levels::LEVEL_ERROR)));
//H4D\Logger::i()
//          ->addWriter(new H4D\Logger\Writer\Screen(array(), array(H4D\Logger\Fields::LEVEL_NAME,
//                                                                  H4D\Logger\Fields::MSG,
//                                                                  H4D\Logger\Fields::MSG_CONTEXT)));
// Add logger to depencenies container
H4D\DI\Container::i()->set('logger', H4D\Logger::i());
// Set propel default logger
//\Propel\Runtime\Propel::getServiceContainer()->setLogger('defaultLogger', H4D\Logger::i());
// Set propel debug mode
//\Propel\Runtime\Propel::getWriteConnection('default')->useDebug(true);
// END: Dependencies ///////////////////////////////////////////////////////////////////////////////