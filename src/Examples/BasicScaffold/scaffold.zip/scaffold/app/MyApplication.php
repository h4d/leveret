<?php

use \H4D\Leveret\Application;

class MyApplication extends Application
{
    public function initRoutes()
    {
        // Register routes
        $this->registerRoute('GET', '/')
             ->useController('DefaultController', 'index');
    }
}