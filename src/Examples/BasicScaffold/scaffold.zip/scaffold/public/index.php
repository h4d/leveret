<?php
require_once(__DIR__.'/../app/bootstrap.php');

$api = new MyApplication(APP_CONFIG_DIR.'/config.ini');
$api->run();